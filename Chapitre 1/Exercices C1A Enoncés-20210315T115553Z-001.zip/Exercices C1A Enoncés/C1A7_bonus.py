# Enoncé 
# A) Importez la bilbiothèque winsound, ensuite utilisez la fonction Beep de cette bibliothèque. Donnez une valeur pour la fréquence et pour la durée
# B) Remplacez les valeurs inscrites en dur par des variables déclarées avant l'appel de la fonction.

#region indice
# Pour importer une bibliothèque, utilisez le petit mot import suivi d'un espace et du nom de la bibliothèque que vous voudrez utiliser.
#endregion

#region indice
# Pour accéder à une fonction de la bibliothèque, écrivez le nom de la bibliothèque suivi d'un point suivi du nom de la fonction que vous voulez utiliser.
#endregion

#region indice
# Une fois la fonction appelée, séparez les données demandée par une virgule. 
# Dans notre cas la fonction beep prend 2 paramètres, une correspondant à la fréquence en Hertz et une autre à la durée en miliseconde.
#endregion


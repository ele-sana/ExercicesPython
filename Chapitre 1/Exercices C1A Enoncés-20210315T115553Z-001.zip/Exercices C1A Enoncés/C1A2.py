# Enoncé : Trouvez 2 façon de ré-écrire Hello World à l'aide de la fonction print, mais cette fois-ci, il doit y avoir un retour à la ligne entre les deux mots.

#region indice
# Pour la première solution, essayez d'utiliser 2 print !
#endregion

#region indice
# le petit code \n équivaut à un retour à la ligne en python.
#endregion

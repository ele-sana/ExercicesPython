# Enoncé : Combinez les deux derniers exercices que l'on a fait. 
# Essayez donc de faire appel à la fonction Beep, mais la fréquence et la durée vont être demandées à l'utilisateur à l'aide de la fonction input.

#region indice
# Déclarez deux variable et assignez leur une valeur donnée par l'input sur deux lignes différentes.
# Dans chacun des inputs, indiquez une petite phrase pour aider l'utilisateur à entrer les bonnes données.
#endregion

#region indice
# Pour connaître le type d'une variable, utiliser la fonction type().
#endregion

#region indice
# La Fonction beep demande deux paramètres de type entier (int), hors la fonction input renvoie une chaîne de caractères (string).
# Pour transformer une chaîne de caractères en entier, il faut simplement la construire. Pour ce faire on met int et on entoure la variable à transformer de parenthèses
# (dans notre cas la fonction input)
#endregion


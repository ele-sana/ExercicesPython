# Enoncé : A l'aide de la fonction print() ecrivez Hello World dans votre console.

#region indice
# Pour accéder à votre console, faites le raccourcis windows + e, tappez cmd
# Dans la console tappez:  CD C:\cheminVersLeDossierContenantCeFichier 
# Ensuite tappez dans la console: python C1A1.py
# Si votre console Ecrit Hello World, c'est bon !
#endregion

#region indice
# Une chaîne de caractère en python commence et termine par des guillemets
#endregion

#region indice
# Essayez de mettre entre guillemet la phrase que vous voulez dans les parenthèses de la fonction print
#endregion

print("hello world")
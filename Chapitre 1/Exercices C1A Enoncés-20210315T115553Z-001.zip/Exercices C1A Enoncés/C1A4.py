# Enoncé : La console demande à l'utilisateur quel est son nom, et stoque le résultat dans une variable appelée Name. 
# Ensuite, le programme dit Hello suivi de prénom rentré par la personne

#region indice
# Pour récupérer une chaîne de caractère donnée par l'utilisateur, on peut utiliser la fonction Input.
#endregion

#region indice
# Pour dire à l'utilisateur de rentrer son nom, on peut soit avant l'appel de la fonction input appeller la fonction print suivi d'un texte
# Ou à l'intérieur des parenthèses du input écrire une chaîne de caractère directement, on va préférer cette deuxième solution !
#endregion


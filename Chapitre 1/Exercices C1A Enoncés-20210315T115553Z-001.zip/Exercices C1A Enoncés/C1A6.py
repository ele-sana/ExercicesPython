# Enoncé : Demandez à l'utilisateur d'entrer 2 chaînes de caractère. Votre programme affichera d'abord la première avec son nombre de caractère, ensuite la deuxième avec
# son nombre de caractère et enfin le nombre de caractère qu'il y a en tout dans les deux chaînes. Il y a deux solutions à trouver.

#region indice
# Dans un premier temps basez votre travail sur la résolution de l'exercice 5, mais en faisant celui-ci deux fois on devrait arriver à afficher les 2 premiers résultats.
#endregion

#region indice
# Une des solution est de coller les deux chaînes de caractère pour ensuite calculer la longueur de la combinaison des deux chaines !
#endregion

#region indice
# La deuxième solution est de calculer le nombre de caractère dans chacune des chaînes et puis les additionner. Ensuite on transforme le résultat en str().
#endregion
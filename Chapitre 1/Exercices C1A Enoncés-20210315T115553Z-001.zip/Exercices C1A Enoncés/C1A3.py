# Enoncé : Déclarez une variable qui s'appelle Name. Dedans est stocké votre prénom. Dans votre fonction print, écrivez Hello suivi du contenu de la variable Name.

#region indice
# Pour déclarer une variable, il suffit de tapper le nom de celle-ci, suivi de signe egal et ensuite le affecter une valeur.
#endregion

#region indice
# Pour concaténer (lier) une chaîne de caractère avec une variable, on peut utiliser le signe +
#endregion

